export const wordsList = {
    carro: ["Motor", "Porta", "Capô", "Pneu", "Antena"],
    fruta: ["Banana", "Maçã", "Pêra", "Mamão", "Laranja"],
    corpo: ["Braço", "Perna", "Cérebro", "Pescoço", "Olhos"],
    computador: ["Mouse", "Teclado", "Monitor", "Gabinete"],
    programação: ["Linguagem", "Framework", "JavaScript", "React"],
    alimento: ["Arroz", "Feijão", "Carne", "Leite", "Ovo"],
    cores: ["Vermelho", "Azul", "Amarelo", "Verde", "Roxo", "Preto", "Branco", "Rosa", "Marrom", "Cinza"],
    animais: ["Cachorro", "Gato", "Elefante", "Girafa", "Leão", "Zebra", "Urso", "Macaco", "Canguru", "Tubarão"],
    países: ["Brasil", "Estados Unidos", "França", "Japão", "Canadá", "Alemanha", "Espanha", "Austrália", "China", "Rússia"],
};
